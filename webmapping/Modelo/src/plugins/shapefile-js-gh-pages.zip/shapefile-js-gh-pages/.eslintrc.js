module.exports = {
  env: {
    browser: true,
    node: true,
    es6: true,
    mocha: true
  },
  extends: 'semistandard'
};

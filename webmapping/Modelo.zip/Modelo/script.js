
let app = new Vue({
el :'#checkboxlayers',
data : {
checkedNames:[],
},
methods:{
    ligarCamadas:(checkedNames)=>{
        
           }
}

});


